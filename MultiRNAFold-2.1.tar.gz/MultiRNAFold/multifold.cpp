
// a simple driver for the multifold

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//#include <time.h>

// include the pairfold library
#include "multifold.h"
#include "externs.h"



int main (int argc, char *argv[])
{
    char sequences[MAXNUMSEQ][MAXSLEN];
    char structure[MAXSUBSTR*MAXSLEN];
    double energy;
    int i;
    int num_sequences;
    
    if (argc < 4)
    {
        printf ("Usage: %s <sequence1> <sequence2> <sequence3> [sequence4] ...\n", argv[0]);
        return 0;
    }    
        
    num_sequences = argc-1;
    for (i = 1; i < argc; i++)
    {
        strcpy (sequences[i-1], argv[i]);
    }
    num_sequences = argc-1;    
    
    // Before calling any function in the library, you have to initialize config_file, dna_or_rna, temperature
    //     and to call the function init_data, which loads the thermodynamic parameters into memory
    
    // configuration file, the path should relative to the location of this executable
    char config_file[200] = "params/multirnafold.conf";

    // what to fold: RNA or DNA
    int dna_or_rna = RNA;

    // temperature: any integer or real number between 0 and 100
    // represents degrees Celsius
    double temperature = 37; 
    
    // initialize the thermodynamic parameters
    // call init_data only once for the same dna_or_rna and same temperature
    // if one of them changes, call init_data again   
    init_data (argv[0], config_file, dna_or_rna, temperature);  

    while(1)
    {
    energy = multifold_ordered (num_sequences, sequences, structure);
    for (i=0; i < num_sequences; i++)
    {
        printf ("%s ", sequences[i]);
    }
    printf ("\n");
    printf ("%s  %.2lf\n", structure, energy);        
    }
    return 0;
}
    






 
