
// a simple driver to write given set of parameters in "almost" mfold format

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// include the simfold header files
#include "simfold.h"
#include "externs.h"
#include "constants.h"
#include "params.h"
#include "common.h"

int main (int argc, char *argv[])
{
    char sequence[MAXSLEN];
    char structure[MAXSLEN];
    char restricted[MAXSLEN];
    char modelfile[200];
    double energy;
    
    if (argc != 2)
    {
        printf ("Usage: %s <model>\n", argv[0]);
        return 0;
    }        
    strcpy (modelfile, argv[1]);
    
    // Before calling any function in the library, you have to initialize config_file, dna_or_rna, temperature
    //     and to call the function init_data, which loads the thermodynamic parameters into memory
    
    // configuration file, the path should relative to the location of this executable
    char config_file[200] = "params/multirnafold.conf";

    // what to fold: RNA or DNA
    int dna_or_rna = RNA;

    // temperature: any integer or real number between 0 and 100
    // represents degrees Celsius
    double temperature = 37; 
    

    read_parsi_options_from_file (modelfile);

    init_data (argv[0], config_file, dna_or_rna, temperature);

    // create string params - precondition for many functions
    num_params = create_string_params ();


    printf ("Param types written in file types.txt");	
    save_paramtypes("types.txt");    
    return 0;
}
    


