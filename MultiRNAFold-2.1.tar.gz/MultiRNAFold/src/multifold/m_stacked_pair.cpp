/***************************************************************************
                          m_stacked_pair.cpp  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <string.h>

#include "constants.h"
#include "structs.h"
#include "externs.h"
#include "common.h"
#include "multifold.h"
#include "m_stacked_pair.h"
#include "m_specific_functions.h"

m_stacked_pair::m_stacked_pair (int *seq, int num_b, int *b, int length)
// The constructor
{
    sequence = seq;     // just refer it from where it is in memory
    seqlen = length;
    this->V = NULL;
    this->b = b;
    this->num_b = num_b;
}



m_stacked_pair::~m_stacked_pair ()
// The destructor
{
}


PARAMTYPE m_stacked_pair::compute_energy (int i, int j)
// compute the free energy of the structure closed by this stacked pair
{
    PARAMTYPE min=INF, local_energy, V_energy;

    if (i+1 >= j-1) return INF;

    V_energy = V->get_energy (i+1,j-1);

    if ( forall_not_equal (num_b, b, i) && forall_not_equal (num_b, b, j-1))
    {
        local_energy = stack[sequence[i]]
                            [sequence[j]]
                            [sequence[i+1]]
                            [sequence[j-1]];

        min = V_energy + local_energy;
    }
    else
    {      
      min = V_energy + misc.intermolecular_initiation +
        AU_penalty (sequence[i], sequence[j]) + 
        AU_penalty (sequence[i+1], sequence[j-1]); 
    }
    return min;

}


PARAMTYPE m_stacked_pair::get_energy (int i, int j, int *sequence, int num_b, int *b)
// returns the free energy of the stacked pair closed at (i,j)   
{
  if (i+1 >= j-1) return INF;
    if ( forall_not_equal (num_b, b, i) && forall_not_equal (num_b, b, j-1))
    {
        return IGINF(stack [sequence[i]]
                     [sequence[j]]
                     [sequence[i+1]]
                     [sequence[j-1]]);
    }
    return misc.intermolecular_initiation +
      AU_penalty (sequence[i], sequence[j]) + 
      AU_penalty (sequence[i+1], sequence[j-1]);  
}


PARAMTYPE m_stacked_pair::get_enthalpy (int i, int j, int *sequence, int num_b, int *b)
// returns the enthalpy of the stacked pair closed at (i,j)   
{
  if (i+1 >= j-1) return INF;
    if ( forall_not_equal (num_b, b, i) && forall_not_equal (num_b, b, j-1))
    {
        return enthalpy_stack [sequence[i]]
                              [sequence[j]]
                              [sequence[i+1]]
                              [sequence[j-1]];
    }
    return enthalpy_misc.intermolecular_initiation + 
      AU_penalty_enthalpy (sequence[i], sequence[j]) + 
      AU_penalty_enthalpy (sequence[i+1], sequence[j-1]);
}
