/***************************************************************************
                          m_specific_functions.h  -  description
                             -------------------
    begin                : Thu Sep 5 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef M_SPECIFIC_FUNCTIONS_H
#define M_SPECIFIC_FUNCTIONS_H

#include <stdio.h>
#include "structs.h"


PARAMTYPE m_dangling_energy (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4);
// PRE:  (i1, i2) and (i3, i4) are pairs, i2 and i3 are neighbours, i2 < i3
// POST: return dangling energy between i2 and i3


PARAMTYPE m_dangling_energy_left (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4);
//      (....(    )   )
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i1 and i3


PARAMTYPE m_dangling_energy_right (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4);
//      (    (    )...)
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i4 and i2


PARAMTYPE m_dangling_enthalpy (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4);
// PRE:  (i1, i2) and (i3, i4) are pairs, i2 and i3 are neighbours, i2 < i3
// POST: return dangling energy between i2 and i3


PARAMTYPE m_dangling_enthalpy_left (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4);
//      (....(    )   )
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i1 and i3


PARAMTYPE m_dangling_enthalpy_right (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4);
//      (    (    )...)
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i4 and i2


int exists_greater (int n, int *b, int term);
// returns true (1) if there is a b > term

int exists_equal (int n, int *b, int term);
// returns true (1) if there is a b = term

int exists_less (int n, int *b, int term);
// returns true (1) if there is a b > term

int exists_greater_and_less (int n, int *b, int term1, int term2);
// returns true (1) if there is a b > term1 and < term2

int forall_not_equal (int n, int *b, int term);
// returns true (1) if all b != term

int forall_less (int n, int *b, int term);
// returns true (1) if all b < term

int forall_greater (int n, int *b, int term);
// returns true (1) if all b > term

#endif







