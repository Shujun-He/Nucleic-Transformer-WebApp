/***************************************************************************
                          m_energy_matrix.cpp  -  description
                             -------------------
    begin                : Fri Apr 12 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>

#include "constants.h"
#include "structs.h"
#include "externs.h"
#include "common.h"
#include "multifold.h"
#include "m_energy_matrix.h"
#include "m_hairpin_loop.h"
#include "m_stacked_pair.h"

m_energy_matrix::m_energy_matrix (int *seq, int num_b, int *b, int length)
// The constructor
{
    this->H = NULL;
    this->S = NULL;
    this->VBI = NULL;
    this->VM = NULL;
    //this->VM_sub = NULL;
    this->b = b;
    this->num_b = num_b;

    sequence = seq;     // just refer it from where it is in memory
    seqlen = length;

    index = new int [length];
	int total_length;
    total_length = (length *(length+1))/2;
    index[0] = 0;
    for (int i=1; i < length; i++)
        index[i] = index[i-1]+length-i+1;

    nodes = new free_energy_node [total_length];
    if (nodes == NULL) giveup ("Cannot allocate memory", "m_energy_matrix");       
}


m_energy_matrix::~m_energy_matrix ()
// The destructor
{
    delete [] index;
    delete [] nodes;
}



void m_energy_matrix::compute_energy (int i, int j)
// PRE:  The energy matrix was calculated
// POST: Do a binary search on nodes
//       Return the energy if found or INF if not found
{
    PARAMTYPE min, min_en[5];
    int k, min_rank;
    char type;

    min = INF;
    min_rank = -1;

    min_en[0] = INF;
    min_en[1] = INF;
    min_en[2] = INF;
    min_en[3] = INF;
    min_en[4] = INF;

    if (can_pair (sequence[i], sequence[j]))
    {
        min_en[0] = H->compute_energy (i, j);
        min_en[1] = S->compute_energy (i, j);
        min_en[2] = VBI->compute_energy (i, j);
        if (i<=j-TURN-1)
          {
            min_en[3] = VM->compute_energy_regular (i, j);
            if (num_b > 0)
              min_en[4] = VM->compute_energy_link (i, j);
          }
    }

   
    for (k=0; k<5; k++)
    {
        if (min_en[k] < min && min_en[k] < INF/2)
        {
            min = min_en[k];
            min_rank = k;
        }
    }

    switch (min_rank)
      {
      case  0: type = HAIRP; break;
      case  1: type = STACK; break;
      case  2: type = INTER; break;
      case  3: type = MULTI; break;
      case  4: type = MULTI_LINK; break;
      default: type = NONE;
      }

    if (min_rank > -1)
    {
        if (debug)
            printf ("V(%d,%d) type %c energy %d\n", i, j, type, min);
    }


    if (min < INF)
    {
        int ij = index[i]+j-i;
        nodes[ij].energy = min;
        nodes[ij].type = type;
    }

}





