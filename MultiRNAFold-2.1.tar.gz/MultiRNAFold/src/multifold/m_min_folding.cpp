/***************************************************************************
                          m_min_folding.cpp  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// Supposing we have the energy matrixes constructed, we compute the best energy

#include <stdio.h>
#include <string.h>

#include "m_min_folding.h"
#include "constants.h"
#include "structs.h"
#include "externs.h"
#include "common.h"
#include "multifold.h"
#include "m_hairpin_loop.h"
#include "m_stacked_pair.h"
#include "m_multi_loop.h"
#include "m_energy_matrix.h"
#include "m_specific_functions.h"

  m_min_folding::m_min_folding (char *sequence)
  {
    check_sequence (sequence);
    this->sequence = sequence;
    num_b = 0;
    allocate_space();
  }


  m_min_folding::m_min_folding (char *sequence1, char *sequence2)
  {
    check_sequence (sequence1);
    check_sequence (sequence2);
    sequence = new char [strlen(sequence1)+strlen(sequence2)+1];
    strcpy (sequence, sequence1);
    strcat (sequence, sequence2);
    num_b = 1;
    b = new int[1];
    b[0] = strlen(sequence1)-1;
    allocate_space();
  }


  m_min_folding::m_min_folding (int num_sequences, char sequences[][MAXSLEN])
  {
    int i, len;
    len = 0;
    num_b = num_sequences - 1;
    b = new int[num_b];
    if (b == NULL) giveup ("Cannot allocate space", "constructor m_min_folding");
    for (i=0; i < num_sequences-1; i++)
      {
        check_sequence (sequences[i]);
        len += strlen (sequences[i]);
        b[i] = len-1;
      }
    check_sequence (sequences[i]);
    len += strlen (sequences[i]);

    sequence = new char [len+1];
    strcpy (sequence, sequences[0]);
    for (i=1; i < num_sequences; i++)
      {
        strcat (sequence, sequences[i]);
      }
    allocate_space();
  }



  void m_min_folding::allocate_space()
  {
    int i;
    self_comp = 0;
    nb_nucleotides = strlen(sequence);
    // allocate the necessary memory

    f = new minimum_fold [nb_nucleotides];
    if (f == NULL) giveup ("Cannot allocate memory", "energy");
    W = new PARAMTYPE [nb_nucleotides];
    if (W == NULL) giveup ("Cannot allocate memory", "energy");
    for (i=0; i < nb_nucleotides; i++) W[i] = 0;

    int_sequence = new int[nb_nucleotides];
    if (int_sequence == NULL) giveup ("Cannot allocate memory", "energy");
    for (i=0; i < nb_nucleotides; i++) int_sequence[i] = nuc_to_int(sequence[i]);

    H = new m_hairpin_loop (sequence, int_sequence, num_b, b, nb_nucleotides);
    if (H == NULL) giveup ("Cannot allocate memory", "energy");
    S = new m_stacked_pair (int_sequence, num_b, b, nb_nucleotides);
    if (S == NULL) giveup ("Cannot allocate memory", "energy");
    VBI = new m_internal_loop (int_sequence, num_b, b, nb_nucleotides);
    if (VBI == NULL) giveup ("Cannot allocate memory", "energy");
    VM = new m_multi_loop (int_sequence, num_b, b, nb_nucleotides);
    if (VM == NULL) giveup ("Cannot allocate memory", "energy");
    V = new m_energy_matrix (int_sequence, num_b, b, nb_nucleotides);
    if (V == NULL) giveup ("Cannot allocate memory", "energy");

    // initialize the structure

    structure = new char[nb_nucleotides+2];
    for (i=0; i<nb_nucleotides; i++)  structure[i] = '.';
    structure[nb_nucleotides] = '\0';

    S->set_energy_matrix (V);
    VBI->set_energy_matrix (V);
    VM->set_energy_matrix (V);
    V->set_loops (H, S, VBI, VM);

  }



  double m_min_folding::simfold_slow_slow ()
    // PRE:  None
    // POST: fold sequence
  {
    double energy;
    energy = fold_sequence ();
    return energy;
  }


  double m_min_folding::pairfold_slow ()
// PRE:  None
// POST: fold sequence
  {
    double energy;
    energy = fold_sequence ();
    insert_space (structure, b[0]);
    //printf ("Structure in pairfold function\n%s\n", structure);
    if (self_comp) energy += 0.43;
    return energy;
}


  m_min_folding::~m_min_folding()
  {
    delete V;
    delete VM;
    delete VBI;
    delete S;
    delete H;
    delete [] f;
    delete [] W;
    delete [] int_sequence;
    delete [] structure;
    if (num_b > 0)
    {
        delete [] b;
        delete [] sequence;
    }
  }


  double m_min_folding::multifold ()
// PRE:  None
// POST: fold sequence
  {
    double energy;
    int i;
    energy = fold_sequence ();
    for (i=num_b-1; i >= 0; i--)
        insert_space (structure, b[i]);
    return energy;
}


double m_min_folding::fold_sequence ()
{
    double energy;
    int i, j;

    for (j=0; j < nb_nucleotides; j++)
    {
        for (i=j-1; i>=0; i--)
        {
            V->compute_energy (i,j);
        }
        // if I put this before V calculation, WM(i,j) cannot be calculated, because it returns infinity

        VM->compute_energy_WM (j);
        if (num_b > 0)
            VM->compute_energy_WM_link (j);            
    }

    for (j=1; j < nb_nucleotides; j++)
    {
        compute_W (j);
    }

    energy = W[nb_nucleotides-1]/100.0;
    //printf ("Energy: %lf\n---\nNow backtracking...\n", energy);

    // backtrack

    // first add (0,n-1) on the stack

    stack_interval = new seq_interval;
    stack_interval->i = 0;
    stack_interval->j = nb_nucleotides - 1;
    stack_interval->energy = W[nb_nucleotides-1]; 
    stack_interval->type = FREE;
    stack_interval->next = NULL;

    seq_interval *cur_interval = stack_interval;

    while ( cur_interval != NULL)
      { 
        stack_interval = stack_interval->next;
        backtrack (cur_interval);
        delete cur_interval;
        cur_interval = stack_interval;
      }

    if (debug)
    {
        print_result ();
    }
    
    return energy;
}



void m_min_folding::insert_node (int i, int j, char type)
  // insert at the beginning
{
  
  seq_interval *tmp;
  tmp = new seq_interval;
  tmp->i = i;
  tmp->j = j;
  tmp->type = type;
  tmp->next = stack_interval;
  stack_interval = tmp;
  //printf ("");  //what's wrong???
}



void m_min_folding::backtrack (seq_interval *cur_interval)
// PRE:  All cells in Vs matrix have been computed
//       j is a column in the matrix Vs
// POST: Read info from Vs matrix, and write into f and structure
//       This function is called when we don't know the pair of j, so we search for the minimum
{
  char type;
  int k;

  if(cur_interval->type == LOOP)
    {
      int i;
      int j;
      i = cur_interval->i;
      j = cur_interval->j;
      f[i].pair = j;
      f[j].pair = i;
      structure[i] = '(';
      structure[j] = ')';
      
      type = V->get_type (i,j);

      if (debug) 
        printf ("\t(%d,%d) LOOP - type %c\n", i,j,type);
      if (type == STACK)
        {
          f[i].type = STACK;
          f[j].type = STACK;
          insert_node (i+1, j-1, LOOP);
        }
      else if (type == HAIRP)
        {
          f[i].type = HAIRP;
          f[j].type = HAIRP;
        }
      else if (type == INTER) 
        {
          f[i].type = INTER;
          f[j].type = INTER;
          // detect the other closing pair
          int ip, jp, best_ip, best_jp, minq;
          PARAMTYPE tmp, min;
          min = INF;
          for (ip = i+1; ip <= MIN(j-2,i+MAXLOOP+1); ip++) 
            {
              minq = MAX (j-i+ip-MAXLOOP-2, ip+1);    
              for (jp = minq; jp < j; jp++)
                {
                  tmp = VBI->get_valid_energy (i,j,ip,jp);
                  if (tmp < min)
                    {
                      min = tmp;
                      best_ip = ip;
                      best_jp = jp;
                    }
                }
            }
          insert_node (best_ip, best_jp, LOOP);
        }
      else if (type == MULTI)
        {
            f[i].type = MULTI;
            f[j].type = MULTI;
            int k, best_k, best_row;
            PARAMTYPE tmp, min;
            min = INF;
            for (k = i+TURN+1; k <= j-TURN-2; k++)
              {
                tmp = VM->get_energy_WM (i+1,k) + VM->get_energy_WM (k+1, j-1);
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 1;
                  }
                tmp = VM->get_energy_WM (i+2,k) + VM->get_energy_WM (k+1, j-1) + 
                  dangle_top [int_sequence[i]][int_sequence[j]][int_sequence[i+1]] + 
                  misc.multi_free_base_penalty;
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 2;
                  }
                tmp = VM->get_energy_WM (i+1,k) + VM->get_energy_WM (k+1, j-2) + 
                  dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]] + 
                  misc.multi_free_base_penalty;
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 3;
                  }
                tmp = VM->get_energy_WM (i+2,k) + VM->get_energy_WM (k+1, j-2) + 
                  dangle_top [int_sequence[i]][int_sequence[j]][int_sequence[i+1]] + 
                  dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]] + 
                  2*misc.multi_free_base_penalty;
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 4;
                  }
              }
            switch (best_row)
              {
              case 1: insert_node (i+1, best_k, M_WM);
                insert_node (best_k+1, j-1, M_WM); break;
              case 2: insert_node (i+2, best_k, M_WM);
                insert_node (best_k+1, j-1, M_WM); break;
              case 3: insert_node (i+1, best_k, M_WM);
                insert_node (best_k+1, j-2, M_WM); break;
              case 4: insert_node (i+2, best_k, M_WM);
                insert_node (best_k+1, j-2, M_WM); break;
              }
          }

        else if (type == MULTI_LINK)
          {
            f[i].type = MULTI_LINK;
            f[j].type = MULTI_LINK;

            int best_row, best_k, best_q;
            PARAMTYPE tmp, min;
            min = INF;
            int q;

            for (q = 0; q < num_b; q++)
              {
                if (b[q] >= i && b[q] < j)
                  {
                    
                    tmp = VM->get_energy_WM_link (i+1,b[q]) + VM->get_energy_WM_link (b[q]+1,j-1);      
                    if (tmp < min)
                      {
                        min = tmp;
                        best_q = q;
                        best_row = 1;
                      }
                    
                    tmp = VM->get_energy_WM_link (i+2,b[q]) + VM->get_energy_WM_link (b[q]+1,j-1);
                    if (forall_not_equal (num_b, b, i))
                      tmp += dangle_top [int_sequence[i]][int_sequence[j]][int_sequence[i+1]];
                    if (tmp < min)
                      {
                        min = tmp;
                        best_q = q;
                        best_row = 2;
                      }
                    
                    tmp = VM->get_energy_WM_link (i+1,b[q]) + VM->get_energy_WM_link (b[q]+1,j-2);
                    if (forall_not_equal (num_b, b, j-1))
                      tmp += dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]];
                    if (tmp < min)
                      {
                        min = tmp;
                        best_q = q;
                        best_row = 3;
                      }
                    
                    tmp = VM->get_energy_WM_link (i+2,b[q]) + VM->get_energy_WM_link (b[q]+1,j-2);
                    if (forall_not_equal (num_b, b, i))
                      tmp += dangle_top [int_sequence[i]][int_sequence[j]][int_sequence[i+1]];
                    if (forall_not_equal (num_b, b, j-1))
                      tmp += dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]];
                    if (tmp < min)
                      {
                        min = tmp;
                        best_q = q;
                        best_row = 4;
                      }
                    
                    for (k = b[q]+1; k < j; k++)
                      {
                        tmp = VM->get_energy_WM_link (b[q]+1,k) + VM->get_energy_WM_link (k+1,j-1);
                        if (forall_not_equal (num_b, b, i)) 
                          tmp += dangle_top[int_sequence[i]][int_sequence[j]][int_sequence[i+1]];
                        if (tmp < min)
                          {
                            min = tmp;
                            best_q = q;
                            best_k = k;
                            best_row = 5;
                          }
                      }
                    
                    for (k = b[q]+1; k < j; k++)
                      {
                        tmp = VM->get_energy_WM_link (b[q]+1,k) + VM->get_energy_WM_link (k+1,j-2);
                        if (forall_not_equal (num_b, b, i)) 
                          tmp += dangle_top[int_sequence[i]][int_sequence[j]][int_sequence[i+1]];
                        if (forall_not_equal (num_b, b, j-1))
                          tmp += dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]];
                        if (tmp < min)
                          {
                            min = tmp;
                            best_q = q;
                            best_k = k;
                            best_row = 6;
                          }
                      }

                    for (k = i+1; k < b[q]; k++)
                      {
                        tmp = VM->get_energy_WM_link (i+1,k) + VM->get_energy_WM_link (k+1,b[q]);
                        if (forall_not_equal (num_b, b, j-1)) 
                          tmp += dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]];
                        if (tmp < min)
                          {
                            min = tmp;
                            best_q = q;
                            best_k = k;
                            best_row = 7;
                          }
                      }
            
                    for (k = i+1; k < b[q]; k++)
                      {
                        tmp = VM->get_energy_WM_link (i+2,k) + VM->get_energy_WM_link (k+1,b[q]);
                        if (forall_not_equal (num_b, b, i))
                          tmp += dangle_top[int_sequence[i]][int_sequence[j]][int_sequence[i+1]];
                        if (forall_not_equal (num_b, b, j-1))
                          tmp += dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]];
                        if (tmp < min)
                          {
                            min = tmp;
                            best_q = q;
                            best_k = k;
                            best_row = 8;
                          }
                      }
                  }
              }

            switch (best_row)
              {
              case 1: insert_node (i+1, b[best_q], M_WM_LINK);
                insert_node (b[best_q]+1, j-1, M_WM_LINK); break;
              case 2: insert_node (i+2, b[best_q], M_WM_LINK);
                insert_node (b[best_q]+1, j-1, M_WM_LINK); break;
              case 3: insert_node (i+1, b[best_q], M_WM_LINK);
                insert_node (b[best_q]+1, j-2, M_WM_LINK); break;
              case 4: insert_node (i+2, b[best_q], M_WM_LINK);
                insert_node (b[best_q]+1, j-2, M_WM_LINK); break;
              case 5: insert_node (b[best_q]+1, best_k, M_WM_LINK);
                insert_node (best_k+1, j-1, M_WM_LINK); break;
              case 6: insert_node (b[best_q]+1, best_k, M_WM_LINK);
                insert_node (best_k+1, j-2, M_WM_LINK); break;
              case 7: insert_node (i+1, best_k, M_WM_LINK);
                insert_node (best_k+1, b[best_q], M_WM_LINK); break;
              case 8: insert_node (i+2, best_k, M_WM_LINK);
                insert_node (best_k+1, b[best_q], M_WM_LINK); break;
              }
          }
    }
  else if(cur_interval->type == FREE)
    {
      int j = cur_interval->j;

      if (j <= TURN) return; 

      int best_row, i, best_i;
      PARAMTYPE min = INF, tmp, acc, energy_ij;

      if (debug)
        printf ("\t(0,%d) FREE\n", j);
      tmp = W[j-1];
      if (tmp < min)
        {
          min = tmp;          
          best_row = 0;
        }
      for (i=0; i<=j-TURN-1; i++)
        {
          acc = (i-1>0) ? W[i-1] : 0;          
          energy_ij = V->get_energy(i,j);
          if (energy_ij < INF)
            {
              tmp = energy_ij + AU_penalty (int_sequence[i],int_sequence[j]) + acc;
              if (tmp < min)
                {
                  min = tmp;
                  best_i = i;
                  best_row = 1;
                }
            }        
          energy_ij = V->get_energy(i+1,j);            
          if (energy_ij < INF)
            {
              tmp = energy_ij + AU_penalty (int_sequence[i+1],int_sequence[j]) + acc;
              if (forall_not_equal (num_b, b, i))
                tmp += dangle_bot [int_sequence[j]][int_sequence[i+1]][int_sequence[i]];
              if (tmp < min)
                {
                  min = tmp;
                  best_i = i;
                  best_row = 2;
                }
            }          
          energy_ij = V->get_energy(i,j-1);
          if (energy_ij < INF)
            {
              tmp = energy_ij + AU_penalty (int_sequence[i],int_sequence[j-1]) + acc;
              if (forall_not_equal (num_b, b, j-1))
                tmp += dangle_top [int_sequence[j-1]][int_sequence[i]][int_sequence[j]];
              if (tmp < min)
                {
                  min = tmp;
                  best_i = i;
                  best_row = 3;
                }
            }                  
          energy_ij = V->get_energy(i+1,j-1);
          if (energy_ij < INF)
            {
              tmp = energy_ij + AU_penalty (int_sequence[i+1],int_sequence[j-1]) + acc;
              if (forall_not_equal (num_b, b, i))
                tmp += dangle_bot [int_sequence[j-1]][int_sequence[i+1]][int_sequence[i]];
              if (forall_not_equal (num_b, b, j-1))
                tmp += dangle_top [int_sequence[j-1]][int_sequence[i+1]][int_sequence[j]];
              if (tmp < min)
                {
                  min = tmp;
                  best_i = i;
                  best_row = 4;
                }
            }
        }
      switch (best_row)
        {
        case 0: insert_node (0, j-1, FREE); break;
        case 1: insert_node (best_i, j, LOOP); 
          if (best_i-1 > TURN) 
            insert_node (0, best_i-1, FREE); 
          break;
        case 2: insert_node (best_i+1, j, LOOP); 
          if (best_i-1 > TURN) 
            insert_node (0, best_i-1, FREE); 
          break;
        case 3: insert_node (best_i, j-1, LOOP); 
          if (best_i-1 > TURN) 
            insert_node (0, best_i-1, FREE); 
          break;
        case 4: insert_node (best_i+1, j-1, LOOP); 
          if (best_i-1 > TURN) 
            insert_node (0, best_i-1, FREE); 
          break;
        }
    }
  else if(cur_interval->type == M_WM)
    {
      int i = cur_interval->i;
      int j = cur_interval->j;
      PARAMTYPE tmp, min = INF;
      int best_k, best_row;

      if (debug)
        printf ("\t (%d,%d) M_WM\n", i,j);

      tmp = V->get_energy(i,j) +
        AU_penalty (int_sequence[i], int_sequence[j]) +
        misc.multi_helix_penalty;
      if (tmp < min)
        {
          min = tmp;
          best_row = 1;
        }

      if ( forall_not_equal (num_b, b, i))
        {
          tmp = V->get_energy(i+1,j) +
            AU_penalty (int_sequence[i+1], int_sequence[j]) +
            dangle_bot [int_sequence[j]]
            [int_sequence[i+1]]
            [int_sequence[i]] +
            misc.multi_helix_penalty +
            misc.multi_free_base_penalty;
          if (tmp < min)
            {
              min = tmp;
              best_row = 2;
            }
        }
      if (forall_not_equal (num_b, b, j-1))
        {
          tmp = V->get_energy(i,j-1) +
                  AU_penalty (int_sequence[i], int_sequence[j-1]) +
                  dangle_top [int_sequence[j-1]]
                             [int_sequence[i]]
                             [int_sequence[j]] +
                  misc.multi_helix_penalty +
                  misc.multi_free_base_penalty;
          if (tmp < min)
            {
              min = tmp;
              best_row = 3;
            }
        }
      if (forall_not_equal (num_b, b, i) && forall_not_equal (num_b, b, j-1))
        {
          tmp = V->get_energy(i+1,j-1) +
                  AU_penalty (int_sequence[i+1], int_sequence[j-1]) +
                  dangle_bot [int_sequence[j-1]]
                             [int_sequence[i+1]]
                             [int_sequence[i]] +
                  dangle_top [int_sequence[j-1]]
                             [int_sequence[i+1]]
                             [int_sequence[j]] +
                  misc.multi_helix_penalty +
                  2*misc.multi_free_base_penalty;
          if (tmp < min)
            {
              min = tmp;
              best_row = 4;
            }
        }
      if (forall_not_equal (num_b, b, i))
        {
          tmp = VM->get_energy_WM (i+1,j) + misc.multi_free_base_penalty;
          if (tmp < min)
            {
              min = tmp;
              best_row = 5;
            }
        }
      if (forall_not_equal (num_b, b, j-1))
        {
          tmp = VM->get_energy_WM (i,j-1) + misc.multi_free_base_penalty;
          if (tmp < min)
            {
              min = tmp;
              best_row = 6;
            }
        }

        for (int k=i; k < j; k++)
          {
            if (exists_equal (num_b, b, k)) continue;
            tmp = VM->get_energy_WM (i, k) + VM->get_energy_WM (k+1, j);
            if (tmp < min)
              {
                min = tmp;
                best_k = k;
                best_row = 7;
              }
          }
        switch (best_row)
          {
          case 1: insert_node (i, j, LOOP); break;
          case 2: insert_node (i+1, j, LOOP); break;
          case 3: insert_node (i, j-1, LOOP); break;
          case 4: insert_node (i+1, j-1, LOOP); break;
          case 5: 
            if (j-i-1 > TURN)
              insert_node (i+1, j, M_WM);
            break;
          case 6:
            if (j-1-i > TURN)
              insert_node (i, j-1, M_WM);
            break;            
          case 7: 
            if (best_k-i > TURN) 
              insert_node (i, best_k, M_WM);
            if (j-best_k-1 > TURN)
              insert_node (best_k+1, j, M_WM); 
            break;
          }        
    }

  else if(cur_interval->type == M_WM_LINK)
    {
      int i = cur_interval->i;
      int j = cur_interval->j;
      PARAMTYPE tmp, min = INF;
      int best_k, best_row;

      if (debug)
        printf ("\t (%d,%d) M_WM_LINK\n", i,j);

      tmp = V->get_energy(i,j) + AU_penalty (int_sequence[i], int_sequence[j]);
      if (tmp < min)
        {
          min = tmp;
          best_row = 1;
        }

      tmp = V->get_energy(i+1,j) + AU_penalty (int_sequence[i+1], int_sequence[j]) + 
        dangle_bot [int_sequence[j]][int_sequence[i+1]][int_sequence[i]];
      if (tmp < min)
        {
          min = tmp;
          best_row = 2;
        }

      tmp = V->get_energy(i,j-1) + AU_penalty (int_sequence[i], int_sequence[j-1]) + 
        dangle_top [int_sequence[j-1]][int_sequence[i]][int_sequence[j]];
      if (tmp < min)
        {
          min = tmp;
          best_row = 3;
        }

      tmp = V->get_energy(i+1,j-1) +
        AU_penalty (int_sequence[i+1], int_sequence[j-1]) + 
                   dangle_bot [int_sequence[j-1]]
                              [int_sequence[i+1]]
                              [int_sequence[i]] +
                   dangle_top [int_sequence[j-1]]
                              [int_sequence[i+1]]
                              [int_sequence[j]];
      if (tmp < min)
        {
          min = tmp;
          best_row = 4;
        }
      
      tmp = VM->get_energy_WM_link (i+1,j);
      if (tmp < min)
        {
          min = tmp;
          best_row = 5;
        }

      tmp = VM->get_energy_WM_link (i,j-1);
      if (tmp < min)
        {
          min = tmp;
          best_row = 6;
        }

      for (int k=i; k < j; k++)
        {
          tmp = VM->get_energy_WM_link (i, k) + VM->get_energy_WM_link (k+1, j);
          if (tmp < min)
            {
              min = tmp;
              best_k = k;
              best_row = 7;
            }
        }
        switch (best_row)
          {
          case 1: insert_node (i, j, LOOP); break;
          case 2: insert_node (i+1, j, LOOP); break;
          case 3: insert_node (i, j-1, LOOP); break;
          case 4: insert_node (i+1, j-1, LOOP); break;
          case 5: 
            if (j-i-1 > TURN)
              insert_node (i+1, j, M_WM_LINK);
            break;
          case 6:
            if (j-1-i > TURN)
              insert_node (i, j-1, M_WM_LINK);
            break;
          case 7: 
            if (best_k-i > TURN)
              insert_node (i, best_k, M_WM_LINK);
            if (j-best_k-1 > TURN)
              insert_node (best_k+1, j, M_WM_LINK); 
            break;
          }


    }
}



PARAMTYPE m_min_folding::compute_W_br2 (int j)
// PRE:  the nucleotide index j and the word it is in (bj) - are given
//          j >= 1
//       min_h is the minimum i that was found
// POST: The second branch of compute_Ws formula.
//       This branch has to consider the AU_penalties and the dangling energies.
{
    PARAMTYPE min = INF, tmp, energy_ij = INF, acc;
    int i;

    for (i=0; i<=j-TURN-1; i++)
    {  
        acc = (i-1>0) ? W[i-1] : 0;
        
        energy_ij = V->get_energy(i,j);
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i],int_sequence[j]) + acc;
            if (tmp < min)
            {
                min = tmp;
            }
        }
        
        energy_ij = V->get_energy(i+1,j);            
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i+1],int_sequence[j]) + acc;
            if (forall_not_equal (num_b, b, i))
                tmp += dangle_bot [int_sequence[j]]
                             [int_sequence[i+1]]
                             [int_sequence[i]];
            if (tmp < min)
            {
                min = tmp;
            }
        }
        
        energy_ij = V->get_energy(i,j-1);
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i],int_sequence[j-1]) + acc;
            if (forall_not_equal (num_b, b, j-1))
                tmp += dangle_top [int_sequence[j-1]]
                             [int_sequence[i]]
                             [int_sequence[j]];
            if (tmp < min)
            {
                min = tmp;
            }
        }

        
        energy_ij = V->get_energy(i+1,j-1);
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i+1],int_sequence[j-1]) + acc;
            if (forall_not_equal (num_b, b, i))
                tmp += dangle_bot [int_sequence[j-1]]
                             [int_sequence[i+1]]
                             [int_sequence[i]];
            if (forall_not_equal (num_b, b, j-1))
                tmp += dangle_top [int_sequence[j-1]]
                             [int_sequence[i+1]]
                             [int_sequence[j]];
            if (tmp < min)
            {
                min = tmp;
            }
        }
    }
    return min;    
}





void m_min_folding::compute_W (int j)
// POST: compute Ws
{
    PARAMTYPE m1, m2;
    m1 = W[j-1];
    m2 = compute_W_br2(j);
    if ((m1 < m2) || (m1 >= MAXENERGY && m2 >= MAXENERGY))
    {
        W[j] = m1;
    }
    else
    {
        W[j] = m2;
    }
}


void m_min_folding::print_result ()
// PRE:  The matrix was calculated and the results written in f
// POST: Prints results
{
    int i;
    PARAMTYPE energy = INF, sum;

    printf ("Minimum energy: %d\n", W[nb_nucleotides-1]);        
    sum = 0;

    for (i=0; i< nb_nucleotides; i++)
    {
        if (f[i].pair > i)
        {
            if (f[i].type == HAIRP)
                energy = V->get_energy(i, f[i].pair);
            else if (f[i].type == STACK)
                energy = V->get_energy(i, f[i].pair) - V->get_energy(i+1, f[i+1].pair);

            /*
            else if (f[i].type == INTER)
            {
                V_node = V->get_node(i, f[i].pair);        
                energy = V_node->energy - V->get_energy (((internal_details *)V_node->details)->prime.i,
                                                         ((internal_details *)V_node->details)->prime.j);
            }

            else if (f[i].type == MULTI)
            {
                multi_details *m_node;
                V_node = V->get_node(i, f[i].pair);        
                m_node = (multi_details*)V_node->details;
                energy = V_node->energy;
                for (k=0; k< m_node->num_branches; k++)
                {
                    pair branch = m_node->branches[k];
                    energy -= V->get_energy (branch.i, branch.j);
                }
            }
            */

            printf ("Pair (%d,%d), type %c,\tenergy %6d\n", i, f[i].pair, f[i].type, energy);
            sum += energy;
        }
    }
    printf ("0....,....1....,....2....,....3....,....4....,....5....,....6....,....7....,....8\n");
    printf ("%s\n", sequence);
    printf ("%s\n", structure);

}
