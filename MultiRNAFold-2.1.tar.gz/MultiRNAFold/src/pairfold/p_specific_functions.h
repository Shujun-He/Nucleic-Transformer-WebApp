/***************************************************************************
                          p_specific_functions.h  -  description
                             -------------------
    begin                : Thu Sep 5 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef P_SPECIFIC_FUNCTIONS_H
#define P_SPECIFIC_FUNCTIONS_H

#include <stdio.h>
#include "structs.h"


PARAMTYPE p_dangling_energy (int *sequence, int link, int i1, int i2, int i3, int i4);
// PRE:  (i1, i2) and (i3, i4) are pairs, i2 and i3 are neighbours, i2 < i3
// POST: return dangling energy between i2 and i3


PARAMTYPE p_dangling_energy_left (int *sequence, int link, int i1, int i2, int i3, int i4);
//      (....(    )   )
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i1 and i3


PARAMTYPE p_dangling_energy_right (int *sequence, int link, int i1, int i2, int i3, int i4);
//      (    (    )...)
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i4 and i2


PARAMTYPE p_dangling_enthalpy (int *sequence, int link, int i1, int i2, int i3, int i4);
// PRE:  (i1, i2) and (i3, i4) are pairs, i2 and i3 are neighbours, i2 < i3
// POST: return dangling enthalpy between i2 and i3


PARAMTYPE p_dangling_enthalpy_left (int *sequence, int link, int i1, int i2, int i3, int i4);
//      (....(    )   )
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling enthalpy between i1 and i3


PARAMTYPE p_dangling_enthalpy_right (int *sequence, int link, int i1, int i2, int i3, int i4);
//      (    (    )...)
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling enthalpy between i4 and i2


PARAMTYPE p_calculate_energy (int link, int *sequence, char *csequence, str_features *f);
// calculate the free energy


PARAMTYPE p_calculate_energy_always_dangle (int link, int *sequence, char *csequence, str_features *f);
// calculate the free energy, when the dangling energies are always added

PARAMTYPE p_calculate_enthalpy (int link, int *sequence, char *csequence, str_features *f);


#endif
