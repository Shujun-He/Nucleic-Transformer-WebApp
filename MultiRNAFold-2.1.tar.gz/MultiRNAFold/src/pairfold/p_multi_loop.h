/***************************************************************************
                          p_multi_loop.h  -  description
                             -------------------
    begin                : Mon Apr 15 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// this class represents multi-loops for MFE pairfold
 
#ifndef P_MULTI_LOOP_H
#define P_MULTI_LOOP_H

#include "structs.h"

class p_energy_matrix;

class p_multi_loop
{
    public:

        friend class p_energy_matrix;

        p_multi_loop (int *seq, int link, int length);
        // The constructor

        ~p_multi_loop ();
        // The destructor

        void set_energy_matrix (p_energy_matrix *V) { this->V = V; }
        // Set local energy matrix to V

        PARAMTYPE compute_energy_regular (int i, int j);
        // computes the free energy of a regular multi-loop closed by (i,j)

        PARAMTYPE compute_energy_link (int i, int j);
        // computes the free energy of a special multi-loop closed by (i,j)

        void compute_energy_WM (int j);
        // computes the free energy of a fragment of a regular multi-loop closed by (i,j)
        
        void compute_energy_WM_link (int j);
        // computes the free energy of a fragment of a special multi-loop closed by (i,j)
                
        PARAMTYPE get_energy_WM (int i, int j) { int ij = index[i]+j-i; return WM[ij]; }
        // returns the previously computed free energy of WM(i,j)
        
        PARAMTYPE get_energy_WM_link (int i, int j) { int ij = index[i]+j-i; return WM_link[ij]; }
        // returns the previously computed free energy of WM-special(i,j)

    private:
        int *sequence;                 // the entire sequence for which we compute the energy
        int seqlen;                     // sequence length
        int link;

        p_energy_matrix *V;               // a pointer to the free energy matrix V

        int *index;
        PARAMTYPE *WM;      // WM - 2D array
        PARAMTYPE *WM_link;      // WM - 2D array

};

#include "p_energy_matrix.h"
#endif

