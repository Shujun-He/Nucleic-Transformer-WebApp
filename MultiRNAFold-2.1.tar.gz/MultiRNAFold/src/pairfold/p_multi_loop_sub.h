/***************************************************************************
                          p_multi_loop_sub.h  -  description
                             -------------------
    begin                : Mon Apr 15 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// this class represents multi-loops for suboptimal pairfold 
 
#ifndef P_MULTI_LOOP_SUB_H
#define P_MULTI_LOOP_SUB_H

#include "structs.h"

class p_energy_matrix;

class p_multi_loop_sub
{
    public:

        friend class p_energy_matrix;

        p_multi_loop_sub (int *seq, int link, int length);
        // The constructor
        
        ~p_multi_loop_sub ();
        // The destructor
        
        void set_energy_matrix (p_energy_matrix *V) { this->V = V; }
        // Set local energy matrix to V

        PARAMTYPE compute_energy (int i, int j);

        PARAMTYPE compute_energy_link (int i, int j);
        
        void compute_energy_FM (int j);
        // PRE:  The energy matrix was calculated
        // POST: 

        void compute_energy_FM_link (int j);
        // PRE:  The energy matrix was calculated
        // POST: 

        void compute_energy_FM1 (int j);
        // PRE:  The energy matrix was calculated
        // POST: 

        void compute_energy_FM1_link (int j);
        // PRE:  The energy matrix was calculated
        // POST: 
        PARAMTYPE get_FM_energy (int i, int j) { if (i>=j) return INF; return FM[index[i]-i+j]; }
        PARAMTYPE get_FM1_energy (int i, int j) { if (i>=j) return INF; return FM1[index[i]-i+j]; }
        PARAMTYPE get_FM_link_energy (int i, int j) { if (i>=j) return INF; return FM_link[index[i]-i+j]; }
        PARAMTYPE get_FM1_link_energy (int i, int j) { if (i>=j) return INF; return FM1_link[index[i]-i+j]; }
        int check_decomp (int i, int j);


    private:
        int *sequence;                 // the entire sequence for which we compute the energy
        int seqlen;                     // sequence length
        int link;

        p_energy_matrix *V;               // a pointer to the free energy matrix V

        int *index;

        PARAMTYPE* FM;  // 2D array to keep the energy for FM
        PARAMTYPE* FM_link;  // 2D array to keep the energy for FM
        PARAMTYPE* FM1;  // 2d array to keep the energy for FM1
        PARAMTYPE* FM1_link;  // 2d array to keep the energy for FM1
        //int* fm_branch;
        //int* fm_branch_link;
        // int* fm1_branch;
        //int* m_decomp;
        //int* fm_decomp;
        //int* fm_decomp_link;
};

#include "p_energy_matrix.h"
#endif

