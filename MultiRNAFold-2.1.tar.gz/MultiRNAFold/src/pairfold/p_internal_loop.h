/***************************************************************************
                          p_internal_loop.h  -  description
                             -------------------
    begin                : Fri Apr 12 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef INTERNAL_LOOP_H
#define INTERNAL_LOOP_H

#include "constants.h"
#include "structs.h"

class p_energy_matrix;

class p_internal_loop
{
    public:

        friend class p_energy_matrix;

        p_internal_loop (int *seq, int link, int length);
        // The constructor

        ~p_internal_loop ();
        // The destructor

        void set_energy_matrix (p_energy_matrix *V) { this->V = V; }
        // Set local energy matrix to V

        PARAMTYPE compute_energy (int i, int j);
        // computes the MFE of the structure closed by the internal loop closed at (i,j)        

        PARAMTYPE get_energy_str (int i, int j, int ip, int jp);
        // returns the free energy of the structure closed by the internal loop (i,j,ip,jp)  

        static PARAMTYPE get_energy (int i, int j, int ip, int jp, int *sequence, int link);
        // returns the free energy of the internal loop closed at (i,j)  

        static PARAMTYPE get_enthalpy (int i, int j, int ip, int jp, int *sequence, int link);
        // returns the enthalpy of the internal loop closed at (i,j)  
        
    private:
        int *sequence;                 // the entire sequence for which we compute the energy
        int seqlen;                     // sequence length
        int link;
        p_energy_matrix *V;               // a pointer to the free energy matrix V   

        
};

#include "p_energy_matrix.h"
#endif
