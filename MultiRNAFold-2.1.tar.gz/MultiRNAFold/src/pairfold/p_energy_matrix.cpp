/***************************************************************************
                          p_energy_matrix.cpp  -  description
                             -------------------
    begin                : Fri Apr 12 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>

#include "constants.h"
#include "structs.h"
#include "externs.h"
#include "common.h"
#include "pairfold.h"
#include "p_energy_matrix.h"
#include "p_hairpin_loop.h"
#include "p_multi_loop_sub.h"
#include "p_stacked_pair.h"

p_energy_matrix::p_energy_matrix (int *seq, int link, int length)
// The constructor
{
    this->H = NULL;
    this->S = NULL;
    this->VBI = NULL;
    this->VM = NULL;
    this->VM_sub = NULL;
    this->link = link;
    int i;

    sequence = seq;     // just refer it from where it is in memory
    seqlen = length;

    index = new int [length];
    int total_length;
    total_length = (length *(length+1))/2;
    index[0] = 0;
    for (i=1; i < length; i++)
        index[i] = index[i-1]+length-i+1;

    nodes = new free_energy_node [total_length];
    if (nodes == NULL) giveup ("Cannot allocate memory", "p_energy_matrix");       
}


p_energy_matrix::~p_energy_matrix ()
// The destructor
{
    delete [] index;
    delete [] nodes;
}



void p_energy_matrix::compute_energy (int i, int j)
// computes the energy of V(i,j)
{
    PARAMTYPE min, min_en[5];
    int k, min_rank;
    char type;
    int ij;

    min = INF;
    min_rank = -1;


    min_en[0] = INF;
    min_en[1] = INF;
    min_en[2] = INF;
    min_en[3] = INF;
    min_en[4] = INF;

    if (can_pair (sequence[i], sequence[j]))
    {
        min_en[0] = H->compute_energy (i, j);
        min_en[1] = S->compute_energy (i, j);
        min_en[2] = VBI->compute_energy (i, j);
        if (i<=j-TURN-1)
          {
            min_en[3] = VM->compute_energy_regular (i, j);
            if (link > 0)
              min_en[4] = VM->compute_energy_link (i, j);
          }
    }

   
    for (k=0; k<5; k++)
    {
        if (min_en[k] < min && min_en[k] < INF/2)
        {
            min = min_en[k];
            min_rank = k;
        }
    }

    switch (min_rank)
      {
      case  0: type = HAIRP; break;
      case  1: type = STACK; break;
      case  2: type = INTER; break;
      case  3: type = MULTI; break;
      case  4: type = MULTI_LINK; break;
      default: type = NONE;
      }

    if (min_rank > -1)
    {
        if (debug)
            printf ("V(%d,%d) type %c energy %d\n", i, j, type, min);
    }


    if (min < INF)
    {
        ij = index[i]+j-i;
        nodes[ij].energy = min;
        nodes[ij].type = type;
    }

}





void p_energy_matrix::compute_energy_sub (int i, int j)
// suboptimals computation for V(i,j)
{
    PARAMTYPE min, min_en[5];
    int k, min_rank;
    char type;
    int ij;

    min = INF;
    min_rank = -1;

 
    min_en[0] = INF;
    min_en[1] = INF;
    min_en[2] = INF;
    min_en[3] = INF;
    min_en[4] = INF;

    if (can_pair (sequence[i], sequence[j]))
    {
        min_en[0] = H->compute_energy (i, j);
        min_en[1] = S->compute_energy (i, j);
        min_en[2] = VBI->compute_energy (i, j);
        if (i<=j-TURN-1)
          {
            min_en[3] = VM_sub->compute_energy (i, j);
            min_en[4] = VM_sub->compute_energy_link (i, j);
          }
    }

    for (k=0; k<5; k++)
    {                
        if (min_en[k] < min)
        {
            min = min_en[k];
            min_rank = k;
        }
    }

    switch (min_rank)
      {
      case  0: type = HAIRP; break;
      case  1: type = STACK; break;
      case  2: type = INTER; break;
      case  3: type = MULTI; break;
      case  4: type = MULTI_LINK; break;
      default: type = NONE;
    }

    ij = index[i]+j-i;
    nodes[ij].energy = min;
    nodes[ij].type = type;
    //    printf ("V(%d,%d) = %d, type=%c\n", i,j, nodes[ij].energy, nodes[ij].type);
}





void p_energy_matrix::compute_energy_simplified (int i, int j)
// MFE computation for V(i,j), only H and S loops are includedd
{
    PARAMTYPE min, min_en[2];
    int k, min_rank;
    char type;
    int ij;

    min = INF;
    min_rank = -1;

    min_en[0] = INF;
    min_en[1] = INF;

    if (can_pair (sequence[i], sequence[j]))
    {
        min_en[0] = H->compute_energy (i, j);
        min_en[1] = S->compute_energy (i, j);
    }

    for (k=0; k<2; k++)
    {
        if (min_en[k] < min)
        {
            min = min_en[k];
            min_rank = k;
        }
    }

    switch (min_rank)
    {
        case  0: type = HAIRP; break;
        case  1: type = STACK; break;
        default: type = NONE;
    }

    if (min_rank > -1)
    {
        if (debug)
            printf ("V(%d,%d) type %c energy %d\n", i, j, type, min);
    }


    if (min < INF)
    {
        ij = index[i]+j-i;
        nodes[ij].energy = min;
        nodes[ij].type = type;
    }

}
