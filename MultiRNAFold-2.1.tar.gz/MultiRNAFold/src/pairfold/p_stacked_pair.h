/***************************************************************************
                          p_stacked_pair.h  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef P_STACKED_PAIR_H
#define P_STACKED_PAIR_H

class p_energy_matrix;

class p_stacked_pair
{
    public:

        friend class p_energy_matrix;

        p_stacked_pair (int *seq, int link, int length);
        // The constructor

        ~p_stacked_pair ();
        // The destructor
    
        void set_energy_matrix (p_energy_matrix *V) { this->V = V; }
        // Set local energy matrix to V
    
        PARAMTYPE compute_energy (int i, int j);
        // compute the free energy of the structure closed by this stacked pair
        
        static PARAMTYPE get_energy (int i, int j, int *sequence, int link);
        // returns the free energy of the stacked pair closed at (i,j)   
        
        static PARAMTYPE get_enthalpy (int i, int j, int *sequence, int link);
        // returns the enthalpy of the stacked pair closed at (i,j)   
                        
    private:
        int *sequence;             // the entire sequence for which we compute the energy
        int seqlen;                 // sequence length
        int link;
        p_energy_matrix *V;           // a pointer to the free energy matrix V

};

#include "p_energy_matrix.h"
#endif
