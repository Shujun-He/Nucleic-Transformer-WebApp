/***************************************************************************
                          p_sub_folding.h  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2003 orginally started by Zhi Chuan Zhang, 
                           continued by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// this class represents free energy minimization and backtracking for pairfold
// WITH suboptimal structures
 
 
#ifndef P_SUB_FOLDING_H
#define P_SUB_FOLDING_H


#include <stdio.h>
#include <string.h>
#include "structs.h"
#include "p_energy_matrix.h"
#include "p_multi_loop_sub.h"



/*
1). What is pushed onto the stack?
    Potential structures which will be further decomposed
2). How to represents the structure pushed onto the stack?
    Linked list of stack_nodes
3). The stack is a list of the linked list
4). How to decompose a structure?
    Take a stack_node out of the linked list. Decompose it and link the decomposed 
    elements back to the list, push the list back onto the stack
    If there are several ways to decompose the list, each way should copy the list and 
    push it back to the stack
5). How to represents the total energy of the structure and how to implement the 
    energy criteria?
    When pop a list out of the stack, the cur_total is CALCULATED.
    Then this total is compared to the min+delta.
6). 
*/

class p_sub_folding
// Keeps all the valid RNA structure on a stack.
// 
{
    public:
 
        // The constructors
        p_sub_folding (char *seq, PARAMTYPE en_var);
        p_sub_folding (char *seq1, char* seq2, PARAMTYPE en_var);

        // The destructor/
        ~p_sub_folding ();
        
        double fold_sequence (double &enthalpy);

        double p_simfold_slow (double &enthalpy);
        double pairfold (double &enthalpy);

        long get_num_partial_structures_thrown_away()  { return num_partial_structures_thrown_away; }; 
        PARAMTYPE compute_W_br2 (int j);

        void compute_W (int j);

        PARAMTYPE calculate_enthalpy (int i);
        void backtrack_hairpin(int i, int j);
        void backtrack_VBI(int i, int j);
        void backtrack_stack(int i, int j);
        void backtrack_multi(int i, int j);
        void backtrack_multi_link(int i, int j);
        void backtrack_freebases(int i, int j);
        void backtrack_freebases1(int i, int j);
        void backtrack_MFM1(int i, int j);
        void backtrack_MFM(int i, int j);
        void backtrack_MFM1_link(int i, int j);
        void backtrack_MFM_link(int i, int j);
        void backtrack();
        struct_node* copy_struct();
        void release_struct(struct_node* sn);
        void print_result(int flag);
        void insert_node(struct_node* sn);
        void set_limit(int limit);
        void adjust();
        
        //int return_structures (char **structures, double energies[]);
        int return_structures (char structures[][MAXSLEN], double energies[]);

    private:
        //char* structure;
        p_hairpin_loop *H;
        p_stacked_pair *S;
        p_internal_loop *VBI;
        p_multi_loop_sub *VM_sub;
        p_energy_matrix *V;  
        int* int_sequence;
        int link;

        //minimum_fold *f;// the minimum folding; 
        PARAMTYPE *W;
        int nb_nucleotides;
        char* sequence;
  
        // A stack of valid structures, each represented by a list
        struct_node* folding_list;

        // M: added
        struct_node *tail_folding_list;      // the last node of the folding_list

        // List represents each valid structure
        seq_interval* intevral_list;

        // Use two temporary variable cur_folding for the struct poped out
        struct_node* cur_folding;
        // Use two temporary variable cur_intevral for the interval that is being backtracked 
        seq_interval* cur_interval;

        // Keep all the valid structure so that it can be printed out
        struct_node *result_list;
        struct_node *last_list;

        // Min_energy 
        PARAMTYPE min_energy;

        // energy variation
        PARAMTYPE en_var;

        // Number of valid structures needed
        int limit;
    
        // M: added
        int num_partial_structures;

        // M: added
        int num_complete_structures;

        // M: added
        PARAMTYPE max_energy;
        // having "limit" partial structures, the energy of the last suboptimal structure (i.e. max_energy) 
        // will be at least as low as the energy of the last partial structure.

        // M: added on July 5th
        long num_partial_structures_thrown_away;

        /* Mybe need to keep pointers to V, FM, FM1, W */
        /* Best way is to put the code in energy.cpp and energy.h in this class */

        void copy_list (seq_interval* from, seq_interval *& to);
        // PRE: from is a linked list
        // POST: copy all linked list from "from" to "to"
        // M: added   


};

#endif //P_SUB_FOLDING_H
