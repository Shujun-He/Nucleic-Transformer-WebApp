/***************************************************************************
                          p_hairpin_loop.h  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef P_HAIRPIN_LOOP_H
#define P_HAIRPIN_LOOP_H


class p_hairpin_loop
{
    public:
        p_hairpin_loop (char * char_seq, int *seq, int link, int length);
        // The constructor

        ~p_hairpin_loop ();
        // The destructor

        PARAMTYPE compute_energy (int i, int j);
        // compute the free energy of the hairpin loop closed at (i,j)

        static PARAMTYPE get_energy (int i, int j, int *sequence, char *csequence, int link);
        // returns the free energy of the hairpin loop closed at (i,j)
        
        static PARAMTYPE get_enthalpy (int i, int j, int *sequence, char *csequence, int link);
        // returns the enthalpy of the hairpin loop closed at (i,j)
                                
    private:
        char *csequence;
        int *sequence;             // the entire sequence for which we compute the energy
        int seqlen;                 // sequence length
        int link;

};


#endif
