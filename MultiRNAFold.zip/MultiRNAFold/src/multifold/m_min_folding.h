/***************************************************************************
                          m_min_folding.h  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef M_MIN_FOLDING_H
#define M_MIN_FOLDING_H


#include <stdio.h>
#include <string.h>
#include "structs.h"
#include "m_energy_matrix.h"
#include "m_multi_loop.h"


class m_min_folding
{
    public:
  
        // The constructors
        m_min_folding (char *seq);
        m_min_folding (char *seq1, char* seq2);
        m_min_folding (int num_sequence, char sequences[][MAXSLEN]);

        // The destructor/
        ~m_min_folding ();
        double simfold_slow_slow ();
        double pairfold_slow ();
        double multifold();
        void set_self_comp (int self_comp) { this->self_comp = self_comp; }
        void return_structure (char *structure) { strcpy (structure, this->structure); }
        

    private:
        char* structure;
        m_hairpin_loop *H;
        m_stacked_pair *S;
        m_internal_loop *VBI;
        m_multi_loop *VM;
        m_energy_matrix *V;  
        int* int_sequence;

        // MF
        int *b;
        int num_b;

        minimum_fold *f;// the minimum folding; 
        PARAMTYPE *W;
        int nb_nucleotides;
        char* sequence;
        int self_comp;
        seq_interval *stack_interval;


        void allocate_space();
        double fold_sequence ();
        void insert_node (int i, int j, char type);
        void backtrack (seq_interval *cur_interval);
        PARAMTYPE compute_W_br2 (int j);
        void compute_W (int j);
        void print_result ();

};

#endif //SUB_FOLDING_H
