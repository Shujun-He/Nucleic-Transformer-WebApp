/***************************************************************************
                          m_hairpin_loop.h  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef M_HAIRPIN_LOOP_H
#define M_HAIRPIN_LOOP_H


class m_hairpin_loop
{
    public:
        m_hairpin_loop (char * char_seq, int *seq, int num_b, int *b, int length);
        // The constructor

        ~m_hairpin_loop ();
        // The destructor

        PARAMTYPE compute_energy (int i, int j);
        // compute the free energy of the structure closed by this hairpin loop

        static PARAMTYPE get_energy (int i, int j, int *sequence, char *csequence, int num_b, int *b);
        // get the FE of this hairpin loop
        
        static PARAMTYPE get_enthalpy (int i, int j, int *sequence, char *csequence, int num_b, int*b);
        // get the enthalpy of this hairpin loop
                                
    private:
        char *csequence;
        int *sequence;             // the entire sequence for which we compute the energy
        int seqlen;                 // sequence length

        // MF
        int *b;
        int num_b;

};


#endif
