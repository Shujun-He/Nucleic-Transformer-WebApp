/***************************************************************************
                          m_multi_loop.h  -  description
                             -------------------
    begin                : Mon Apr 15 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef M_MULTI_LOOP_H
#define M_MULTI_LOOP_H

#include "structs.h"

class m_energy_matrix;

class m_multi_loop
{
    public:

        friend class m_energy_matrix;

        m_multi_loop (int *seq, int num_b, int *b, int length);
        // The constructor

        ~m_multi_loop ();
        // The destructor

        void set_energy_matrix (m_energy_matrix *V) { this->V = V; }
        // Set local energy matrix to V

        PARAMTYPE compute_energy_regular (int i, int j);
        // computes MFE of a regular multi-loop closed by (i,j)

        PARAMTYPE compute_energy_link (int i, int j);
        // computes MFE of a special multi-loop closed by (i,j)

        void compute_energy_WM (int j);
        // computes MFE of a regular multi-loop fragment closed by (i,j)

        void compute_energy_WM_link (int j);
        // computes MFE of a special multi-loop fragment closed by (i,j)
        
        PARAMTYPE get_energy_WM (int i, int j) { if (i>=j) return INF; int ij = index[i]+j-i; return WM[ij]; }
        // return WM(i,j)
        
        PARAMTYPE get_energy_WM_link (int i, int j) { if (i>=j) return INF; int ij = index[i]+j-i; return WM_link[ij]; }
        // return WM special (i,j)


    private:
        int *sequence;                 // the entire sequence for which we compute the energy
        int seqlen;                     // sequence length

        // MF
        int *b;
        int num_b;

        m_energy_matrix *V;               // a pointer to the free energy matrix V

        int *index;
        PARAMTYPE *WM;      // WM - 2D array
        PARAMTYPE *WM_link;      // WM - 2D array

};

#include "m_energy_matrix.h"
#endif

