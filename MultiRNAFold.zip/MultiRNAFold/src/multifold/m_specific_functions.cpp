/***************************************************************************
                          m_specific_functions.cpp  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/


// This file contains common functions, that may be used throughout the library

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "constants.h"
#include "structs.h"
#include "externs.h"
#include "common.h"
#include "multifold.h"
#include "m_min_folding.h"
#include "m_specific_functions.h"


PARAMTYPE m_dangling_energy (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4)
//      (   )...(   )
//      i1..i1..i3..i4
// PRE:  (i1, i2) and (i3, i4) are pairs, i2 and i3 are neighbours, i2 < i3
// POST: return dangling energy between i2 and i3
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    if (forall_not_equal (num_b, b, i2)) 
        d_top = MIN (0, IGINF(dangle_top[sequence[i2]]
                          [sequence[i1]]
                          [sequence[i2+1]]));
    if (forall_not_equal (num_b, b, i3-1))                          
        d_bot = MIN (0, IGINF(dangle_bot[sequence[i4]]
                          [sequence[i3]]
                          [sequence[i3-1]]));
    if (i2+1 == i3-1 && exists_equal (num_b, b, i2))
        energy = d_bot;
    else if (i2+1 == i3-1 && exists_equal (num_b, b, i3-1))
        energy = d_top;     
    else if (i2+1 == i3-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i2+1 < i3-1)
    {
        energy = d_top + d_bot;
    }


    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


PARAMTYPE m_dangling_energy_left (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4)
//      (....(    )   )
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i1 and i3
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    // this will be used in multi-loops.
    // add the dangle_top, even if it is positive
    if (forall_not_equal (num_b, b, i1))
        d_top = MIN (0, IGINF(dangle_top[sequence[i1]]
                          [sequence[i2]]
                          [sequence[i1+1]]));
    // in the other parts of the multi-loop, the dangles are added only if they are negative
    if (forall_not_equal (num_b, b, i3-1))
        d_bot = MIN (0, IGINF(dangle_bot[sequence[i4]]
                          [sequence[i3]]
                          [sequence[i3-1]]));
    if (i1+1 == i3-1 && exists_equal (num_b, b, i1))
        energy = d_bot;
    else if (i1+1 == i3-1 && exists_equal (num_b, b, i3-1))
        energy = d_top;
    else if (i1+1 == i3-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i1+1 < i3-1)
    {
        energy = d_top + d_bot;
    }
    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


PARAMTYPE m_dangling_energy_right (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4)
//      (    (    )...)
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i4 and i2
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    if (forall_not_equal (num_b, b, i4))
        d_top = MIN (0, IGINF(dangle_top[sequence[i4]]
                          [sequence[i3]]
                          [sequence[i4+1]]));
    if (forall_not_equal (num_b, b, i2-1))
        d_bot = MIN (0, IGINF(dangle_bot[sequence[i1]]
                          [sequence[i2]]
                          [sequence[i2-1]]));
    if (i4+1 == i2-1 && exists_equal (num_b, b, i4))
        energy = d_bot;
    else if (i4+1 == i2-1 && exists_equal (num_b, b, i2-1))
        energy = d_top;
    else if (i4+1 == i2-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i4+1 < i2-1)
    {
        energy = d_top + d_bot;
    }
    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


PARAMTYPE m_dangling_enthalpy (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4)
//      (   )...(   )
//      i1..i1..i3..i4
// PRE:  (i1, i2) and (i3, i4) are pairs, i2 and i3 are neighbours, i2 < i3
// POST: return dangling enthalpy between i2 and i3
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    if (forall_not_equal (num_b, b, i2))
        d_top = MIN (0, enthalpy_dangle_top[sequence[i2]]
                          [sequence[i1]]
                          [sequence[i2+1]]);
    if (forall_not_equal (num_b, b, i3-1))
        d_bot = MIN (0, enthalpy_dangle_bot[sequence[i4]]
                          [sequence[i3]]
                          [sequence[i3-1]]);
    if (i2+1 == i3-1 && exists_equal (num_b, b, i2))
        energy = d_bot;
    else if (i2+1 == i3-1 && exists_equal (num_b, b, i3-1))
        energy = d_top;
    else if (i2+1 == i3-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i2+1 < i3-1)
    {
        energy = d_top + d_bot;
    }

    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


PARAMTYPE m_dangling_enthalpy_left (int *sequence, int num_b, int *b, int i1, int i2, int i3, int i4)
//      (....(    )   )
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling enthalpy between i1 and i3
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    // this will be used in multi-loops.
    // add the dangle_top, even if it is positive
    if (forall_not_equal (num_b, b, i1))
        d_top = MIN (0, enthalpy_dangle_top[sequence[i1]]
                          [sequence[i2]]
                          [sequence[i1+1]]);
    // in the other parts of the multi-loop, the dangles are added only if they are negative
    if (forall_not_equal (num_b, b, i3-1))
        d_bot = MIN (0, enthalpy_dangle_bot[sequence[i4]]
                          [sequence[i3]]
                          [sequence[i3-1]]);
    if (i1+1 == i3-1 && exists_equal (num_b, b, i1))
        energy = d_bot;
    else if (i1+1 == i3-1 && exists_equal (num_b, b, i3-1))
        energy = d_top;
    else if (i1+1 == i3-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i1+1 < i3-1)
    {
        energy = d_top + d_bot;
    }
    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


PARAMTYPE m_dangling_enthalpy_right (int *sequence, int num_b, int* b, int i1, int i2, int i3, int i4)
//      (    (    )...)
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling enthalpy between i4 and i2
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    if (forall_not_equal (num_b, b, i4))
        d_top = MIN (0, enthalpy_dangle_top[sequence[i4]]
                          [sequence[i3]]
                          [sequence[i4+1]]);
    if (forall_not_equal (num_b, b, i2-1))
        d_bot = MIN (0, enthalpy_dangle_bot[sequence[i1]]
                          [sequence[i2]]
                          [sequence[i2-1]]);
    if (i4+1 == i2-1 && exists_equal (num_b, b, i4))
        energy = d_bot;
    else if (i4+1 == i2-1 && exists_equal (num_b, b, i2-1))
        energy = d_top;
    else if (i4+1 == i2-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i4+1 < i2-1)
    {
        energy = d_top + d_bot;
    }
    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}




int exists_greater (int n, int *link, int term)
// returns true (1) if there is a b > term
{
    int i;
    for (i=0; i < n; i++)
    {
        if (link[i] > term)
            return 1;
    }
    return 0;
}


int exists_equal (int n, int *link, int term)
// returns true (1) if there is a b = term
{
    int i;
    for (i=0; i < n; i++)
    {
        if (link[i] == term)
            return 1;
    }
    return 0;
}


int exists_less (int n, int *link, int term)
// returns true (1) if there is a b < term
{
    int i;
    for (i=0; i < n; i++)
    {
        if (link[i] < term)
            return 1;
    }
    return 0;
}


int exists_greater_and_less (int n, int *link, int term1, int term2)
// returns true (1) if there is a b > term1 and < term2
{
    int i;
    for (i=0; i < n; i++)
    {
        if (link[i] > term1 && link[i] < term2)
            return 1;
    }
    return 0;
}

int forall_not_equal (int n, int *link, int term)
// returns true (1) if all b != term
{
  int i;
  for (i=0; i < n; i++)
    {
      if (link[i] == term)
        return 0;
    }
  return 1;
}

int forall_less (int n, int *link, int term)
// returns true (1) if all b < term
{
  int i;
  for (i=0; i < n; i++)
    {
      if (link[i] >= term)
        return 0;
    }
  return 1;
}

double multifold_ordered (int num_sequences, char sequences[MAXNUMSEQ][MAXSLEN], char structure[MAXSUBSTR*MAXSLEN])
{
    double energy;
    m_min_folding *min_fold = new m_min_folding (num_sequences, sequences);
    energy = min_fold->multifold();
    min_fold->return_structure (structure);
    delete min_fold;
    return energy;
}

int forall_greater (int n, int *link, int term)
// returns true (1) if all b > term
{
  int i;
  for (i=0; i < n; i++)
    {
      if (link[i] < term)
        return 0;
    }
  return 1;
}

















 
 
 
 
     