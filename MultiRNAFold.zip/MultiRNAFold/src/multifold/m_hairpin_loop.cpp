/***************************************************************************
                          m_hairpin_loop.cpp  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <string.h>

#include "constants.h"
#include "structs.h"
#include "externs.h"
#include "common.h"
#include "multifold.h"
#include "m_hairpin_loop.h"
#include "m_specific_functions.h"


m_hairpin_loop::m_hairpin_loop (char * char_seq, int *seq, int num_b, int *b, int length)
// The constructor
{
    csequence = char_seq;
    sequence = seq;     // just refer it from where it is in memory
    seqlen = length;
    this->b = b;
    this->num_b = num_b;
}



m_hairpin_loop::~m_hairpin_loop ()
// The destructor
{
}

PARAMTYPE m_hairpin_loop::compute_energy (int i, int j)
// compute the free energy of the structure closed by this hairpin loop
{
    PARAMTYPE energy;
    energy=0;
    if (exists_greater_and_less (num_b, b, i-1, j))
    {
        if (forall_not_equal (num_b, b, i))       // i is not the last base of sequence1, so there is a dangling base
            energy = dangle_top  [sequence[i]]  [sequence[j]]  [sequence[i+1]];
        if (forall_not_equal (num_b, b, j-1))     // j is not the first base of sequence2, so there is a dangling base
            energy += dangle_bot [sequence[i]]  [sequence[j]]  [sequence[j-1]];
        energy += misc.intermolecular_initiation;            
        energy += AU_penalty (sequence[i], sequence[j]);
        return energy;
    }        

    PARAMTYPE terminal_mismatch_energy, bonus, special_bonus, AU_pen;
    int k, is_poly_C;
    int size;
    char seq[6];

    terminal_mismatch_energy = 0; bonus = 0; special_bonus = 0; AU_pen = 0;
    strcpy (seq, "");
    size = j-i-1;
 
    if (size < 3)
        return INF;
    else if (size == 3)
    {
        terminal_mismatch_energy = 0;
        AU_pen = AU_penalty (sequence[i], sequence[j]);
    }
    else
    {
        terminal_mismatch_energy =
             tstackh[sequence[i]]
                    [sequence[j]]
                    [sequence[i+1]]
                    [sequence[j-1]];
    }

    #if (MODEL == SIMPLE)
    // check if it is a triloop
    if (size == 3)
    {
        substr (csequence, i, j, seq);

        for (k=0; k < nb_triloops; k++)
        {
            if (strcmp (seq, triloop[k].seq) == 0)
                bonus = triloop[k].energy;
        }
    }
    
    // check to see it is a tetraloop in tloop
    if (size == 4)

    {
        substr (csequence, i, j, seq);
        for (k=0; k < nb_tloops; k++)
        {
            if (strcmp (seq, tloop[k].seq) == 0)
                bonus = tloop[k].energy;
        }
    }
    #endif

    // special_bonus from miscloop file
    // check if we have to apply "GGG" loop special bonus
    // to come back - Vienna doesn't have it

    if (i > 1)
    {
        if (sequence[i-2] == G && sequence[i-1] == G &&
            sequence[i] == G && sequence[j] == U)
            special_bonus += misc.hairpin_GGG;
    }
    

    // check for the special case of "poly-C" hairpin loop
    is_poly_C = 1;
    for (k=i+1; k<j; k++)
    {
        if (sequence[k] != C)
        {
            is_poly_C = 0;
            break;
        }
    }
    if (is_poly_C)
    {
        if (size == 3)
            special_bonus += misc.hairpin_c3;
        else
            special_bonus += misc.hairpin_c2 + misc.hairpin_c1 * size;
    }

    energy = penalty_by_size (size, 'H') +
             terminal_mismatch_energy + bonus + special_bonus + AU_pen;
    return energy;
}


PARAMTYPE m_hairpin_loop::get_energy (int i, int j, int* sequence, char *csequence, int num_b, int*b)
// get the FE of this hairpin loop
{
    PARAMTYPE energy;
    energy=0;
    if (exists_greater_and_less (num_b, b, i-1, j))
    {
        if (forall_not_equal (num_b, b, i))      // i is not the last base of sequence1, so there is a dangling base
            energy = IGINF(dangle_top  [sequence[i]]  [sequence[j]]  [sequence[i+1]]);
        if (forall_not_equal (num_b, b, j-1))    // j is not the first base of sequence2, so there is a dangling base
            energy += IGINF(dangle_bot [sequence[i]]  [sequence[j]]  [sequence[j-1]]);
        energy += misc.intermolecular_initiation;
        energy += AU_penalty (sequence[i], sequence[j]);
        return energy;
    }

    PARAMTYPE terminal_mismatch_energy, bonus, special_bonus, AU_pen;
    int k, is_poly_C;
    int size;
    char seq[6];


    terminal_mismatch_energy = 0; bonus = 0; special_bonus = 0; AU_pen = 0;
    strcpy (seq, "");

    size = j-i-1;

    if (size < 3)
        return INF;
    else if (size == 3)
    {
        terminal_mismatch_energy = 0;
        AU_pen = AU_penalty (sequence[i], sequence[j]);
    }
    else
    {
        terminal_mismatch_energy =
             IGINF(tstackh[sequence[i]]
                    [sequence[j]]
                    [sequence[i+1]]
                    [sequence[j-1]]);
    }

    #if (MODEL == SIMPLE)
    // check if it is a triloop
    if (size == 3)
    {
        substr (csequence, i, j, seq);
        for (k=0; k < nb_triloops; k++)
        {
            if (strcmp (seq, triloop[k].seq) == 0)
                bonus = triloop[k].energy;
        }
    }

    // check to see it is a tetraloop in tloop
    if (size == 4)
    {
        substr (csequence, i, j, seq);
        for (k=0; k < nb_tloops; k++)   // nb_tloops should be the same as for energy
        {
            if (strcmp (seq, tloop[k].seq) == 0)
                bonus = tloop[k].energy;
        }
    }
    #endif

    // special_bonus from miscloop file
    // check if we have to apply "GGG" loop special bonus
    // to come back - Vienna doesn't have it

    if (i > 1)
    {
        if (sequence[i-2] == G && sequence[i-1] == G &&
            sequence[i] == G && sequence[j] == U)
            special_bonus += misc.hairpin_GGG;
    }


    // check for the special case of "poly-C" hairpin loop
    is_poly_C = 1;
    for (k=i+1; k<j; k++)
    {

        if (sequence[k] != C)
        {
            is_poly_C = 0;
            break;
        }
    }
    if (is_poly_C)
    {
        if (size == 3)
            special_bonus += misc.hairpin_c3;
        else
            special_bonus += misc.hairpin_c2 + misc.hairpin_c1 * size;
    }

    energy = penalty_by_size (size, 'H') +
             terminal_mismatch_energy + bonus + special_bonus + AU_pen;
    return energy;
}


PARAMTYPE m_hairpin_loop::get_enthalpy (int i, int j, int* sequence, char *csequence, int num_b, int *b)
// get the enthalpy of this hairpin loop
{
    PARAMTYPE energy;
    energy=0;
    if (exists_greater_and_less (num_b, b, i-1, j))
    {
        if (forall_not_equal (num_b, b, i))       // i is not the last base of sequence1, so there is a dangling base
            energy = enthalpy_dangle_top  [sequence[i]]  [sequence[j]]  [sequence[i+1]];
        if (forall_not_equal (num_b, b, j-1))     // j is not the first base of sequence2, so there is a dangling base
            energy += enthalpy_dangle_bot [sequence[i]]  [sequence[j]]  [sequence[j-1]];
        energy += enthalpy_misc.intermolecular_initiation;
        energy += AU_penalty_enthalpy (sequence[i], sequence[j]);
        return energy;
    }

    PARAMTYPE terminal_mismatch_energy, bonus, special_bonus, AU_pen;
    int k, is_poly_C;
    int size;
    char seq[6];

    terminal_mismatch_energy = 0; bonus = 0; special_bonus = 0; AU_pen = 0;
    strcpy (seq, "");

    size = j-i-1;

    if (size < 3)
        return INF;
    else if (size == 3)
    {
        terminal_mismatch_energy = 0;
        AU_pen = AU_penalty_enthalpy (sequence[i], sequence[j]);
    }
    else
    {
        terminal_mismatch_energy =
             enthalpy_tstackh[sequence[i]]
                    [sequence[j]]
                    [sequence[i+1]]
                    [sequence[j-1]];
    }

    // check if it is a triloop
    if (size == 3)
    {
        substr (csequence, i, j, seq);
        for (k=0; k < enthalpy_nb_triloops; k++)
        {
            if (strcmp (seq, enthalpy_triloop[k].seq) == 0)
                bonus = enthalpy_triloop[k].energy;
        }
    }

    // check to see it is a tetraloop in tloop
    if (size == 4)
    {
        substr (csequence, i, j, seq);
        for (k=0; k < enthalpy_nb_tloops; k++)   // nb_tloops should be the same as for energy
        {
            if (strcmp (seq, enthalpy_tloop[k].seq) == 0)
                bonus = enthalpy_tloop[k].energy;
        }
    }

    // special_bonus from miscloop file
    // check if we have to apply "GGG" loop special bonus
    // to come back - Vienna doesn't have it

    if (i > 1)
    {
        if (sequence[i-2] == G && sequence[i-1] == G &&
            sequence[i] == G && sequence[j] == U)
            special_bonus += enthalpy_misc.hairpin_GGG;
    }


    // check for the special case of "poly-C" hairpin loop
    is_poly_C = 1;
    for (k=i+1; k<j; k++)
    {

        if (sequence[k] != C)
        {
            is_poly_C = 0;
            break;
        }
    }
    if (is_poly_C)
    {
        if (size == 3)
            special_bonus += enthalpy_misc.hairpin_c3;
        else
            special_bonus += enthalpy_misc.hairpin_c2 + enthalpy_misc.hairpin_c1 * size;
    }

    energy = penalty_by_size_enthalpy (size, 'H') +
             terminal_mismatch_energy + bonus + special_bonus + AU_pen;
    return energy;
}
