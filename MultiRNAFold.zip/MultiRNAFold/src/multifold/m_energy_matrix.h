/***************************************************************************
                          m_energy_matrix.h  -  description
                             -------------------
    begin                : Fri Apr 12 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef M_ENERGY_MATRIX_H
#define M_ENERGY_MATRIX_H

#include "m_stacked_pair.h"
#include "m_hairpin_loop.h"
#include "m_internal_loop.h"
#include "m_multi_loop.h"


class m_energy_matrix
{
    public:

        friend class m_stacked_pair;
        friend class m_internal_loop;
        friend class m_multi_loop;

        m_energy_matrix (int *seq, int num_b, int *b, int length);
        // constructor
        
        ~m_energy_matrix ();
        // The destructor

        void set_loops (m_hairpin_loop *H, m_stacked_pair *S,
                        m_internal_loop *VBI, m_multi_loop *VM)
        // Set the local loops to the given values
        {
            this->H = H;
            this->S = S;
            this->VBI = VBI;
            this->VM = VM;        
        }

        void compute_energy (int i, int j);
        // compute MFE of the structure closed by the pair (i,j)

        void compute_energy_sub (int i, int j);
        // compute free energy (with suboptimals) of the structure closed by the pair (i,j)

        void compute_energy_simplified (int i, int j);
        // compute MFE of the structure closed by the pair (i,j)
        // only stacked paird (S) and hairpin loops (H) are included        

        PARAMTYPE get_energy (int i, int j) { if (i>=j) return INF; int ij = index[i]+j-i; return nodes[ij].energy; }
        // get V(i,j)

        char get_type (int i, int j) { if (i>=j) return NONE; int ij = index[i]+j-i; return nodes[ij].type; }
        // get type of V(i,j)


    private:
        m_hairpin_loop *H;
        m_stacked_pair *S;
        m_internal_loop *VBI;
        m_multi_loop *VM;

        int *sequence;             // the entire sequence for which we compute the energy
        int seqlen;                 // sequence length
        int *index;
        free_energy_node *nodes;  // hairpin nodes in a 1D array

        // MF
        int *b;
        int num_b;

};



#endif
