// use of pairfold for the RNAsoft web page

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

// include the pairfold library
#include "pairfold.h"
#include "timer.h"

#define LEN 1000

   

int main (int argc, char *argv[])
{
    char sequence1[LEN], sequence2[LEN];
    int what_to_fold;
    char buffer[LEN];
    char structure[2*LEN];
    double energy, enthalpy, entropy, Tm, target_conc1, target_conc2, salt_conc;
    int self_comp;  //0=true, 1=false
    int i;
    timer stpw;
    
    // configuration file
    //char config_file[200] = "prog/params/pairfold.conf";
    char config_file[200] = "params/pairfold.conf";
    char input_file[200];
    char output_file[200];
    double temperature;

    strcpy (input_file, argv[1]);
    strcpy (output_file, argv[2]);
    FILE *ifile;
    FILE *ofile;

    if ((ifile = fopen (input_file,"r")) == NULL)
    {
        printf ("Cannot open file %s", input_file);
        exit(1);
    }
    fgets (buffer, sizeof(buffer), ifile);
    for (i=0; i < strlen(buffer); i++)
    {
        if (buffer[i] == '\n')
        {
            buffer[i] = '\0';
            break;
        }
    }
    strcpy (sequence1, buffer);
    fgets (buffer, sizeof(buffer), ifile);
    for (i=0; i < strlen(buffer); i++)
    {
        if (buffer[i] == '\n')
        {
            buffer[i] = '\0';
            break;
        }
    }
    strcpy (sequence2, buffer);
    // what to fold: RNA or DNA
    fgets (buffer, sizeof(buffer), ifile);
    if (buffer[0] == 'D') what_to_fold = DNA;
    else what_to_fold = RNA;
    // temperature
    fgets (buffer, sizeof(buffer), ifile);
    temperature = strtod (buffer, (char**)NULL);
    // param k for Tm
    fgets (buffer, sizeof(buffer), ifile);
    self_comp = atoi (buffer);
    // target concentration of Seq 1
    fgets (buffer, sizeof(buffer), ifile);
    target_conc1 = strtod (buffer, (char**)NULL);    
    // target concentration of Seq 2
    fgets (buffer, sizeof(buffer), ifile);
    target_conc2 = strtod (buffer, (char**)NULL);
    // salt concentration
    fgets (buffer, sizeof(buffer), ifile);
    salt_conc = strtod (buffer, (char**)NULL);    
    fclose(ifile);

    if ((ofile = fopen (output_file,"w")) == NULL)
    {
        printf ("Cannot open file %s", output_file);
        exit(1);
    }

    // initialize the thermodynamic parameters
    // call init_data only once for the same dna_or_rna and same temperature
    // if one of them changes, call init_data again (see below)
    init_data (argv[0], config_file, what_to_fold, temperature);
    stpw.reset();
    stpw.start();
    //energy = pairfold (sequence1, sequence2, structure, 0);
    energy = pairfold_mfe (sequence1, sequence2, structure); //, 0);
    enthalpy = enthalpy_pairfold (sequence1, sequence2, structure);
    entropy = calc_entropy (energy, enthalpy, temperature);
    Tm = calc_Tm (enthalpy, entropy, target_conc1, target_conc2, self_comp, salt_conc);
    fprintf (ofile, "%s\n%.2f\n%.2f\n%.5f\n%.2f\n", structure, energy, enthalpy, entropy, Tm);
    
    energy = pairfold_mfe (sequence1, sequence1, structure); //, 0);
    enthalpy = enthalpy_pairfold (sequence1, sequence1, structure);
    entropy = calc_entropy (energy, enthalpy, temperature);
    Tm = calc_Tm (enthalpy, entropy, target_conc1, target_conc1, self_comp, salt_conc);    
    fprintf (ofile, "%s\n%.2f\n%.2f\n%.5f\n%.2f\n", structure, energy, enthalpy, entropy, Tm);
    
    energy = pairfold_mfe (sequence2, sequence2, structure); //, 0);
    enthalpy = enthalpy_pairfold (sequence2, sequence2, structure);
    entropy = calc_entropy (energy, enthalpy, temperature);
    Tm = calc_Tm (enthalpy, entropy, target_conc2, target_conc2, self_comp, salt_conc);    
    fprintf (ofile, "%s\n%.2f\n%.2f\n%.5f\n%.2f\n", structure, energy, enthalpy, entropy, Tm);
    
    stpw.stop();
    fprintf (ofile, "%4.2f\n", stpw.elapsed());
    fclose (ofile);
    return 0;
}


