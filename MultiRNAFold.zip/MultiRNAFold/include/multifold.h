/***************************************************************************
                          multifold.h  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/


#ifndef MULTIFOLD_H
#define MULTIFOLD_H

#define RNA   0
#define DNA   1

#include "constants.h"
#include "init.h"


double multifold_ordered (int num_sequences, char sequences[MAXNUMSEQ][MAXSLEN], char structure[MAXSUBSTR*MAXSLEN]);


#endif


